package com.example.taskmanager.views;

import com.example.taskmanager.entity.Task;
import com.example.taskmanager.service.TaskService;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;

@Route("")
public class MainView extends VerticalLayout {
    private final TaskService taskService = new TaskService();

    public MainView() {
        add(new RouterLink("Adicionar Nova Tarefa", TaskDetailView.class));

        Grid<Task> taskGrid = new Grid<>(Task.class, false);
        taskGrid.addColumn(Task::getName).setHeader("Tarefa");
        taskGrid.addColumn(task -> task.isCompleted() ? "Sim" : "Não").setHeader("Concluída");
        taskGrid.addComponentColumn(task -> {
            Button completeButton = new Button("Concluir", click -> {
                task.setCompleted(true);
                taskGrid.getDataProvider().refreshAll();
            });
            completeButton.setEnabled(!task.isCompleted());
            return completeButton;
        });

        taskGrid.setItems(taskService.getTasks());
        add(taskGrid);
    }
}
