package com.example.advancedinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedInventoryApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdvancedInventoryApplication.class, args);
    }
}
