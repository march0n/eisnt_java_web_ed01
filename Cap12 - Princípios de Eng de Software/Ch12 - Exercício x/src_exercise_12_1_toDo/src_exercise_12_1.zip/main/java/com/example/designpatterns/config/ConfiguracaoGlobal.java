package com.example.designpatterns.config;

import org.springframework.stereotype.Component;

@Component
public class ConfiguracaoGlobal {

    private String appName = "Minha Aplicação";

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }
}
