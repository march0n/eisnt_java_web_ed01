package com.example.designpatterns.factory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServicoFactory {

    @Bean
    public Servico exemploServico() {
        return new ServicoConcreto();
    }
}

interface Servico {
    void executar();
}

class ServicoConcreto implements Servico {
    @Override
    public void executar() {
        System.out.println("Serviço Concreto Executado!");
    }
}
