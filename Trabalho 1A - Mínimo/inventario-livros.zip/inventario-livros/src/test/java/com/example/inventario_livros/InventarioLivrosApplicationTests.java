package com.example.inventario_livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioLivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
