package com.example.inventario_livros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioLivrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioLivrosApplication.class, args);
	}

}
